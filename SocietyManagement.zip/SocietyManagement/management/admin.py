from django.contrib import admin
from .models import SocialEvent, MaintenanceEvent, Notice, Member

# Register the models to be manageable via the admin panel

class SocialEventAdmin(admin.ModelAdmin):
    list_display = ('title', 'date', 'location', 'created_by')  # Columns to display
    search_fields = ('title', 'location')  # Fields to search by
    list_filter = ('date',)  # Filter options for events by date

class MaintenanceEventAdmin(admin.ModelAdmin):
    list_display = ('title', 'date', 'maintenance_cost', 'created_by')  # Columns to display
    search_fields = ('title',)
    list_filter = ('date',)  # Filter events by date

class NoticeAdmin(admin.ModelAdmin):
    list_display = ('title', 'posted_date', 'created_by')  # Columns to display
    search_fields = ('title',)  # Search by title
    list_filter = ('posted_date',)  # Filter by posted date

class MemberAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'phone', 'join_date')  # Display these columns
    search_fields = ('name', 'email', 'phone')  # Fields to search by

# Register the models to make them available in the admin panel
admin.site.register(SocialEvent, SocialEventAdmin)
admin.site.register(MaintenanceEvent, MaintenanceEventAdmin)
admin.site.register(Notice, NoticeAdmin)
admin.site.register(Member, MemberAdmin)
