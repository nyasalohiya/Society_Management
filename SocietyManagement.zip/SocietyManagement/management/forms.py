from django import forms
from .models import SocialEvent, MaintenanceEvent, Notice,Member

class SocialEventForm(forms.ModelForm):
    class Meta:
        model = SocialEvent
        fields = ['title', 'description', 'date', 'time', 'location']

class MaintenanceEventForm(forms.ModelForm):
    class Meta:
        model = MaintenanceEvent
        fields = ['title', 'description', 'date', 'time', 'maintenance_cost']

class NoticeForm(forms.ModelForm):
    class Meta:
        model = Notice
        fields = ['title', 'description']

class MemberForm(forms.ModelForm):
    class Meta:
        model = Member
        fields = ['name', 'email', 'phone', 'address']