from django.urls import path
from . import views
from .views import list_members, add_member, edit_member, delete_member

urlpatterns = [
    path('', views.homepage, name='homepage'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('register/', views.register, name='register'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('add-social-event/', views.add_social_event, name='add_social_event'),
    path('add-maintenance-event/', views.add_maintenance_event, name='add_maintenance_event'),
    path('add-notice/', views.add_notice, name='add_notice'),
    path('members/', list_members, name='list_members'),
    path('members/add/', add_member, name='add_member'),
    path('members/edit/<int:pk>/', edit_member, name='edit_member'),
    path('members/delete/<int:pk>/', delete_member, name='delete_member'),
]
