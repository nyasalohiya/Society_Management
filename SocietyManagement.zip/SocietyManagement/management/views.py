from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import SocialEvent, MaintenanceEvent, Notice,Member
from .forms import SocialEventForm, MaintenanceEventForm, NoticeForm,MemberForm

@login_required
def list_members(request):
    members = Member.objects.all()
    return render(request, 'management/members_list.html', {'members': members})

@login_required
def add_member(request):
    if request.method == 'POST':
        form = MemberForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Member added successfully!")
            return redirect('list_members')
    else:
        form = MemberForm()
    return render(request, 'management/add_member.html', {'form': form})

@login_required
def edit_member(request, pk):
    member = get_object_or_404(Member, pk=pk)
    if request.method == 'POST':
        form = MemberForm(request.POST, instance=member)
        if form.is_valid():
            form.save()
            messages.success(request, "Member updated successfully!")
            return redirect('list_members')
    else:
        form = MemberForm(instance=member)
    return render(request, 'management/edit_member.html', {'form': form, 'member': member})

@login_required
def delete_member(request, pk):
    member = get_object_or_404(Member, pk=pk)
    if request.method == 'POST':
        member.delete()
        messages.success(request, "Member deleted successfully!")
        return redirect('list_members')
    return render(request, 'management/confirm_delete.html', {'member': member})

    
# Home page redirect based on user authentication status
def homepage(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    return render(request, 'management/homepage.html')

# Dashboard view showing events and notices
@login_required
def dashboard(request):
    social_events = SocialEvent.objects.all()
    maintenance_events = MaintenanceEvent.objects.all()
    notices = Notice.objects.all()
    members = Member.objects.all()

    context = {
        'social_events': social_events,
        'maintenance_events': maintenance_events,
        'notices': notices,
        'members': members,
    }
    return render(request, 'management/dashboard.html', context)

# Registration view
def register(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')  # Get the email field
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')

        # ✅ Check if passwords match
        if password != confirm_password:
            messages.error(request, "Passwords do not match.")
            return redirect('register')

        # ✅ Check if the username already exists
        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already exists. Please choose a different one.")
            return redirect('register')

        # ✅ Create the user
        user = User.objects.create_user(username=username, email=email, password=password)
        user.save()

        messages.success(request, "Registration successful! Please log in.")
        return redirect('login')
        print(f"Username: {username}, Email: {email}, Password: {password}")

    return render(request, 'management/register.html')

# Login view
def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('dashboard')
        else:
            messages.error(request, "Invalid username or password.")
            return redirect('login')
    return render(request, 'management/login.html')

# Logout view
def logout_view(request):
    logout(request)
    return redirect('homepage')

# Add a new social event
@login_required
def add_social_event(request):
    if request.method == 'POST':
        form = SocialEventForm(request.POST)
        if form.is_valid():
            social_event = form.save(commit=False)
            social_event.created_by = request.user
            social_event.save()
            return redirect('dashboard')
    else:
        form = SocialEventForm()

    return render(request, 'management/add_event.html', {'form': form})

# Add a new maintenance event
@login_required
def add_maintenance_event(request):
    if request.method == 'POST':
        form = MaintenanceEventForm(request.POST)
        if form.is_valid():
            maintenance_event = form.save(commit=False)
            maintenance_event.created_by = request.user
            maintenance_event.save()
            messages.success(request, "Maintenance event added successfully!")
            return redirect('dashboard')
        else:
            messages.error(request, "There was an error with the form. Please check the input.")
    else:
        form = MaintenanceEventForm()

    return render(request, 'management/add_event.html', {'form': form})

# Add a new notice
@login_required
def add_notice(request):
    if request.method == 'POST':
        form = NoticeForm(request.POST)
        if form.is_valid():
            notice = form.save(commit=False)
            notice.created_by = request.user
            notice.save()
            return redirect('dashboard')
    else:
        form = NoticeForm()

    return render(request, 'management/add_notice.html', {'form': form})
